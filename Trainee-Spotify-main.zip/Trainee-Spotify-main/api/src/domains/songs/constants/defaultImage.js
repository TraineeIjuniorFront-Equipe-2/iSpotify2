const defaultImage = 'https://i.pinimg.com/originals/ce/72/76/ce72765f290c39c44aca1a2a8c03cac3.jpg';
module.exports = defaultImage;