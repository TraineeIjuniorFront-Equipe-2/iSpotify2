const userRoles = {
  admin: 'admin',
  user: 'user',
};

module.exports = userRoles;